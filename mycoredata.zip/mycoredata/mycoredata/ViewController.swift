//
//  ViewController.swift
//  mycoredata
//
//  Created by MACOS on 6/17/17.
//  Copyright © 2017 MACOS. All rights reserved.
//

import UIKit
import CoreData

class ViewController: UIViewController,UITableViewDataSource,UITableViewDelegate {

    
    
    let context = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
    var final = [Any]()
    
    @IBOutlet var tbl: UITableView!
    @IBOutlet var txtid: UITextField!
    @IBOutlet var txtname: UITextField!
    @IBOutlet var txtadd: UITextField!
   
    override func viewDidLoad() {
        super.viewDidLoad()
        
            }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    @IBAction func btnInsert(_ sender: Any) {
       
      let newcontect = NSEntityDescription.insertNewObject(forEntityName: "Emp", into: context) as NSManagedObject
        
        newcontect.setValue(txtid.text, forKey: "id")
        newcontect.setValue(txtname.text, forKey: "name")
        newcontect.setValue(txtadd.text, forKey: "add")
        
        do
        {
          try context.save()
            print("Record insert successfully")
        }
        catch
        {
            
        }
        
    }

    @IBAction func btnupdate(_ sender: Any) {
    
        
        let entitydis = NSEntityDescription.entity(forEntityName: "Emp", in: context);
        
        let request = NSFetchRequest<NSFetchRequestResult>(entityName: "Emp")
        request.entity = entitydis;
        
        let pred = NSPredicate(format: "(id= %@)", txtid.text!);
        
        //  var err = NSError();
        
        request.predicate = pred
        
        do{
            
            let results = try context.fetch(request);
            
            //print(results)
            
            if results.count>0
            {
                
                let match =  results[0] as! NSManagedObject;
                
                match.setValue(txtid.text, forKey: "id")
                match.setValue(txtname.text, forKey: "name")
                match.setValue(txtadd.text, forKey: "add")
                
                print("Record updated successfully")
                
                do
                {
                    try context.save()
                }
                catch
                {
                    
                }
            }
            else
            {
                print("not fount")
            }
            
            
        }catch{
            fatalError("Error is upate items")
        }
        

    }

    @IBAction func btndelete(_ sender: Any) {
        
        let entitydis = NSEntityDescription.entity(forEntityName: "Emp", in: context);
        
        let request = NSFetchRequest<NSFetchRequestResult>(entityName: "Emp")
        request.entity = entitydis;
        
        let pred = NSPredicate(format: "(id= %@)", txtid.text!);
        
        //  var err = NSError();
        
        request.predicate = pred
        
        do{
            
            let results = try context.fetch(request);
            
            //print(results)
            
            if results.count>0
            {
                
                let match =  results[0] as! NSManagedObject;
                
                context.delete(match)
                print("Deleted successfully")
                
                do
                {
                  try context.save()
                }
                catch
                {
                    
                }
            }
            else
            {
                print("not fount")
            }
            
  
        }catch{
            fatalError("Error is delete items")
        }

    }
    
    @IBAction func btnselect(_ sender: Any) {

        let entitydis = NSEntityDescription.entity(forEntityName: "Emp", in: context);
        
        let request = NSFetchRequest<NSFetchRequestResult>(entityName: "Emp")
        request.entity = entitydis;
        
        let pred = NSPredicate(format: "(id= %@)", txtid.text!);
        
        //  var err = NSError();
        
        request.predicate = pred
        
        do{
            
            let results = try context.fetch(request);
            
            //print(results)
            
            if results.count>0
            {
                
                let match =  results[0] as! NSManagedObject;
                
                txtadd.text = match.value(forKey: "add") as?String
                
                txtid.text = match.value(forKey: "id") as? String
                
                txtname.text  = match.value(forKey: "name") as? String
                
                
            }
            else
            {
                print("not fount")
            }
        

             final = results as! [NSManagedObject]
             print(final)
             //tbl.reloadData()
        
        }catch{
            fatalError("Error is retriving items")
        }
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 3
    }
    
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell")
        
        
       // let dicfinal = final[indexPath.section] as! [String]
        
        //cell?.textLabel?.text = dicfinal[indexPath.row]
        
        return cell!
    }
}
